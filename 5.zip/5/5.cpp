﻿#include <iostream>
#include <clocale>

using namespace std;

double Sum_AP(double a1, double d, int n) {
    
    if (n <= 0) {
        cerr << "Ошибка: количество элементов должно быть положительным!" << endl;
        return 0;
    }
    return (2 * a1 + d * (n - 1)) * n / 2;
}

int main() {
    setlocale(LC_ALL, "Russian");

    double a1, d;
    int n;

    cout << "Введите первый элемент прогрессии (a1): ";
    cin >> a1;

    cout << "Введите разность прогрессии (d): ";
    cin >> d;

    cout << "Введите количество элементов (n): ";
    cin >> n;
 
    double result = Sum_AP(a1, d, n);
    if (result != 0) {
        cout << "Сумма арифметической прогрессии: " << result << endl;
    }
    return 0;
}