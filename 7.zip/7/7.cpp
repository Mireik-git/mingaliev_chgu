﻿#include <iostream>
#include <vector>
#include <iomanip>
#include <clocale>

using namespace std;
double calculateWeeklyDistance(const vector<bool>& weather, int week_start, int week_end, double sunny_dist, double cloudy_dist) {
    double distance = 0;
    for (int i = week_start; i <= week_end && i < weather.size(); i++) {
        distance += weather[i] ? sunny_dist : cloudy_dist;
    }
    return distance;
}
double calculateTotalDistance(const vector<bool>& weather, double sunny_dist, double cloudy_dist) {
    double total = 0;
    for (bool day : weather) {
        total += day ? sunny_dist : cloudy_dist;
    }
    return total;
}
double calculateAverageSpeed(double total_distance, int days) {
    return total_distance / days;
}

int main() {
    setlocale(LC_ALL, "Russian");

    double S1, S2;
    int days_in_month;

    cout << "Введите расстояние в солнечный день (S1): ";
    cin >> S1;
    cout << "Введите расстояние в пасмурный день (S2): ";
    cin >> S2;
    cout << "Введите количество дней в месяце: ";
    cin >> days_in_month;

    vector<bool> weather(days_in_month);
    cout << "Введите погоду за каждый день (1 - солнечный, 0 - пасмурный):\n";
    for (int i = 0; i < days_in_month; i++) {
        int input;
        cin >> input;
        weather[i] = (input == 1);
    }
    cout << "\n1. Расстояние за каждую неделю:\n";
    int weeks = (days_in_month + 6) / 7;
    for (int week = 0; week < weeks; week++) {
        int start = week * 7;
        int end = start + 6;
        double dist = calculateWeeklyDistance(weather, start, end, S1, S2);
        cout << "Неделя " << week + 1 << ": " << fixed << setprecision(2) << dist << " м\n";
    }
    double total_dist = calculateTotalDistance(weather, S1, S2);
    cout << "\n2. Общее расстояние за месяц: " << fixed << setprecision(2) << total_dist << " м\n";

    double avg_speed = calculateAverageSpeed(total_dist, days_in_month);
    cout << "3. Средняя скорость: " << fixed << setprecision(2) << avg_speed << " м/день\n";

    return 0;
}