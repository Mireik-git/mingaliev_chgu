﻿#include <iostream>
#include <cmath>
#include <clocale>

using namespace std;

int main() {
    setlocale(LC_ALL, "Russian");

    double squareX, squareY, side;
    cout << "Введите координаты левого верхнего угла квадрата (x y): ";
    cin >> squareX >> squareY;
    cout << "Введите длину стороны квадрата: ";
    cin >> side;

    double x1, y1, x2, y2;
    cout << "Введите координаты концов отрезка (x1 y1 x2 y2): ";
    cin >> x1 >> y1 >> x2 >> y2;

    double left = squareX;
    double right = squareX + side;
    double bottom = squareY - side;
    double top = squareY;

    int result = 0;
    bool point1Inside = (x1 >= left && x1 <= right && y1 >= bottom && y1 <= top);
    bool point2Inside = (x2 >= left && x2 <= right && y2 >= bottom && y2 <= top);

    if (point1Inside && point2Inside) result = 2;
    else if (point1Inside || point2Inside) result = 1;

    switch (result) {
    case 0: cout << "Отрезок вне квадрата." << endl; break;
    case 1: cout << "Отрезок пересекает квадрат." << endl; break;
    case 2: cout << "Отрезок полностью внутри квадрата." << endl; break;
    default: cout << "Ошибка анализа." << endl;
    }

    return 0;
}