﻿#include <iostream>
#include <cmath>
#include <clocale>

using namespace std;

int main() {
    setlocale(LC_ALL, "Russian");

    int R;
    cout << "Введите радиус окружности R: ";
    cin >> R;

    int K = 0;

    for (int x = -R; x < R; ++x) {
        for (int y = -R; y < R; ++y) {
            bool isInside = true;
            for (int dx = 0; dx <= 1; ++dx) {
                for (int dy = 0; dy <= 1; ++dy) {
                    double distance = sqrt(pow(x + dx, 2) + pow(y + dy, 2));
                    if (distance > R) {
                        isInside = false;
                        break;
                    }
                }
                if (!isInside) break;
            }
            if (isInside) K++;
        }
    }

    cout << "Количество клеток: " << K << endl;
    return 0;
}