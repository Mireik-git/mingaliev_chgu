﻿#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
using namespace std;

struct Toy {
    string name;      
    double price;      
    int minAge;         
    int maxAge;         
};

Toy inputToy() {
    Toy toy;
    cout << "Введите название игрушки: ";
    getline(cin >> ws, toy.name);

    cout << "Введите стоимость игрушки: ";
    cin >> toy.price;

    cout << "Введите минимальный возраст: ";
    cin >> toy.minAge;

    cout << "Введите максимальный возраст: ";
    cin >> toy.maxAge;

    return toy;
}

void printToy(const Toy& toy) {
    cout << "Название: " << toy.name << endl;
    cout << "Стоимость: " << toy.price << " руб." << endl;
    cout << "Возрастной диапазон: от " << toy.minAge << " до " << toy.maxAge << " лет" << endl;
    cout << "--------------------------------" << endl;
}

vector<Toy> findByName(const vector<Toy>& toys, const string& name) {
    vector<Toy> result;
    for (const auto& toy : toys) {
        if (toy.name.find(name) != string::npos) {
            result.push_back(toy);
        }
    }
    return result;
}

vector<Toy> findByPrice(const vector<Toy>& toys, double price) {
    vector<Toy> result;
    for (const auto& toy : toys) {
        if (toy.price == price) {
            result.push_back(toy);
        }
    }
    return result;
}

vector<Toy> findByAge(const vector<Toy>& toys, int age) {
    vector<Toy> result;
    for (const auto& toy : toys) {
        if (age >= toy.minAge && age <= toy.maxAge) {
            result.push_back(toy);
        }
    }
    return result;
}

vector<Toy> findToys(const vector<Toy>& toys, const string& name, double price, int age) {
    vector<Toy> result;
    for (const auto& toy : toys) {
        if ((name.empty() || toy.name.find(name) != string::npos) &&
            (price == 0 || toy.price == price) &&
            (age == 0 || (age >= toy.minAge && age <= toy.maxAge))) {
            result.push_back(toy);
        }
    }
    return result;
}

int main() {
    setlocale(LC_ALL, "Russian");

    vector<Toy> toys;

    cout << "Введите количество игрушек: ";
    int count;
    cin >> count;

    for (int i = 0; i < count; ++i) {
        cout << "\nИгрушка #" << i + 1 << ":\n";
        toys.push_back(inputToy());
    }

    cout << "\nСписок всех игрушек:\n";
    for (const auto& toy : toys) {
        printToy(toy);
    }

    int choice;
    do {
        cout << "\nВыберите тип поиска:\n";
        cout << "1 - По названию\n";
        cout << "2 - По цене\n";
        cout << "3 - По возрасту\n";
        cout << "4 - По всем параметрам\n";
        cout << "0 - Выход\n";
        cout << "Ваш выбор: ";
        cin >> choice;

        vector<Toy> foundToys;

        switch (choice) {
        case 1: {
            string name;
            cout << "Введите название для поиска: ";
            getline(cin >> ws, name);
            foundToys = findByName(toys, name);
            break;
        }
        case 2: {
            double price;
            cout << "Введите цену для поиска: ";
            cin >> price;
            foundToys = findByPrice(toys, price);
            break;
        }
        case 3: {
            int age;
            cout << "Введите возраст для поиска: ";
            cin >> age;
            foundToys = findByAge(toys, age);
            break;
        }
        case 4: {
            string name;
            double price;
            int age;

            cout << "Введите название (или оставьте пустым): ";
            getline(cin >> ws, name);

            cout << "Введите цену (или 0 для любого): ";
            cin >> price;

            cout << "Введите возраст (или 0 для любого): ";
            cin >> age;

            foundToys = findToys(toys, name, price, age);
            break;
        }
        }

        if (choice != 0) {
            cout << "\nНайдено " << foundToys.size() << " игрушек:\n";
            for (const auto& toy : foundToys) {
                printToy(toy);
            }
        }

    } while (choice != 0);

    return 0;
}