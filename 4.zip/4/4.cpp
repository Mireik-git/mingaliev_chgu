﻿#include <iostream>
#include <iomanip>
#include <clocale>

using namespace std;

int main() {
    setlocale(LC_ALL, "Russian");

    double N, C;
    int K;

    cout << "Введите начальный объем продаж (тыс. руб.): ";
    cin >> N;
    cout << "Введите себестоимость пары тапочек (руб.): ";
    cin >> C;
    cout << "Введите количество лет (K): ";
    cin >> K;

    cout << fixed << setprecision(2);
    cout << "Год | Объем продаж (тыс. руб.) | Себестоимость (руб.) | Прибыль (тыс. руб.)" << endl;
    cout << "------------------------------------------------------------" << endl;

    for (int year = 1; year <= K; ++year) {
        double profit = N * 1000 - (N * 1000 / C) * C;
        cout << year << "   | " << N << "                  | " << C << "               | " << profit / 1000 << endl;
        N *= 1.05;
        C *= 0.99;
    }

    return 0;
}