﻿#include <iostream>
#include <cmath>
#include <iomanip>
#include <clocale>

using namespace std;

int main() {
    setlocale(LC_ALL, "Russian");

    double side1, side2, side3;

    cout << "Введите длину первой стороны: ";
    cin >> side1;
    cout << "Введите длину второй стороны: ";
    cin >> side2;
    cout << "Введите длину третьей стороны: ";
    cin >> side3;

    if (side1 + side2 <= side3 || side1 + side3 <= side2 || side2 + side3 <= side1) {
        cerr << "Ошибка: Треугольник с такими сторонами не существует!" << endl;
        return 1;
    }

    double semi_perimeter = (side1 + side2 + side3) / 2;
    double area = sqrt(semi_perimeter * (semi_perimeter - side1) * (semi_perimeter - side2) * (semi_perimeter - side3));

    cout << fixed << setprecision(2);
    cout << "Площадь треугольника: " << area << endl;

    return 0;
}