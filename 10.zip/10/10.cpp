﻿#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

void inputRatings(vector<vector<int>>& ratings) {
    cout << "Введите оценки 3 экспертов для 10 кандидатов (по 20-балльной шкале):\n";
    for (int i = 0; i < 10; ++i) {
        cout << "Кандидат " << i + 1 << ": ";
        vector<int> expertRatings(3);
        for (int j = 0; j < 3; ++j) {
            cin >> expertRatings[j];
        }
        ratings.push_back(expertRatings);
    }
}

vector<int> calculateSums(const vector<vector<int>>& ratings) {
    vector<int> sums;
    for (const auto& candidate : ratings) {
        int sum = 0;
        for (int score : candidate) {
            sum += score;
        }
        sums.push_back(sum);
    }
    return sums;
}

void printTable(const vector<vector<int>>& ratings, const vector<int>& sums) {
    cout << "\nОценочная таблица:\n";
    cout << "Кандидат\tЭксперт 1\tЭксперт 2\tЭксперт 3\tСумма\n";
    for (int i = 0; i < 10; ++i) {
        cout << i + 1 << "\t\t";
        for (int j = 0; j < 3; ++j) {
            cout << ratings[i][j] << "\t\t";
        }
        cout << sums[i] << endl;
    }
}

void findTop3(const vector<int>& sums) {
    vector<pair<int, int>> candidateSums;
    for (int i = 0; i < sums.size(); ++i) {
        candidateSums.emplace_back(sums[i], i + 1);
    }

    sort(candidateSums.rbegin(), candidateSums.rend());

    cout << "\nТоп-3 кандидатов:\n";
    for (int i = 0; i < 3 && i < candidateSums.size(); ++i) {
        cout << i + 1 << " место: Кандидат " << candidateSums[i].second
            << " (Сумма баллов: " << candidateSums[i].first << ")\n";
    }
}

int main() {
    setlocale(LC_ALL, "Russian");

    vector<vector<int>> ratings;

    inputRatings(ratings);
    vector<int> sums = calculateSums(ratings);
    printTable(ratings, sums);
    findTop3(sums);

    return 0;
}