﻿#include <iostream>
#include <fstream>
#include <vector>
#include <cctype>
#include <sstream>
#include <clocale>
#include <windows.h>

using namespace std;

bool isEachWordCapitalized(const string& str) {
    if (str.empty()) return false;

    bool new_word = true;
    for (char c : str) {
        if (new_word && isalpha(c)) {
            if (!isupper(c)) return false;
            new_word = false;
        }
        else if (isspace(c)) {
            new_word = true;
        }
    }
    return true;
}

string convertNameFormat(const string& full_name) {
    vector<string> parts;
    istringstream iss(full_name);
    string part;

    while (iss >> part) {
        parts.push_back(part);
    }

    if (parts.size() != 3) return full_name;

    string result = parts[2] + " "; // Фамилия
    result += parts[0].substr(0, 1) + "."; // Инициал имени
    result += parts[1].substr(0, 1) + "."; // Инициал отчества

    return result;
}

void processNamesFile(const string& input_file, const string& output_file) {
    ifstream fin(input_file);
    ofstream fout(output_file);

    if (!fin.is_open()) {
        cerr << "Ошибка открытия входного файла!" << endl;
        return;
    }
    if (!fout.is_open()) {
        cerr << "Ошибка открытия выходного файла!" << endl;
        fin.close();
        return;
    }

    string line;
    while (getline(fin, line)) {
        if (isEachWordCapitalized(line)) {
            string converted = convertNameFormat(line);
            fout << converted << endl;
        }
        else {
            cerr << "Ошибка формата: " << line << endl;
        }
    }

    fin.close();
    fout.close();
}

int main() {
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);
    setlocale(LC_ALL, "Russian");

    ofstream test_input("F1.txt");
    if (test_input.is_open()) {
        test_input << "Данил Ильдарович Мингалиев\n";
        test_input << "Данис Минсурович Ямалиев\n";
        test_input << "Рияз Рашитович Хамбиков\n";
        test_input.close();
    }

    string my_name = "Данил Ильдарович Мингалиев";
    cout << "Проверка вашего ФИО:\n";
    cout << "Исходный формат: " << my_name << endl;
    cout << "Преобразованный: " << convertNameFormat(my_name) << endl;

    processNamesFile("F1.txt", "F2.txt");
    cout << "Преобразование завершено. Результат в файле F2.txt" << endl;

    ifstream check("F2.txt");
    if (check.is_open()) {
        cout << "\nСодержимое файла F2.txt:\n";
        string content;
        while (getline(check, content)) {
            cout << content << endl;
        }
        check.close();
    }
    else {
        cerr << "Не удалось открыть файл F2.txt для проверки" << endl;
    }

    return 0;
}