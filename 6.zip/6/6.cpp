﻿#include <iostream>
#include <cstdlib>
#include <ctime>
#include <clocale>

using namespace std;


void inputArray(int* arr, int size) {
    cout << "Введите " << size << " элементов массива:\n";
    for (int i = 0; i < size; i++) {
        cin >> arr[i];
    }
}


void printArray(int* arr, int size) {
    cout << "Массив: [";
    for (int i = 0; i < size; i++) {
        cout << arr[i];
        if (i < size - 1) cout << ", ";
    }
    cout << "]\n";
}


double checkArithmetic(int* arr, int size) {
    if (size < 2) return 0;

    int d = arr[1] - arr[0];
    for (int i = 2; i < size; i++) {
        if (arr[i] - arr[i - 1] != d) {
            return 0;
        }
    }
    return d;
}


double checkGeometric(int* arr, int size) {
    if (size < 2) return 1;


    if (arr[0] == 0) return 1;

    double q = (double)arr[1] / arr[0];
    for (int i = 2; i < size; i++) {
        if (arr[i - 1] == 0 || (double)arr[i] / arr[i - 1] != q) {
            return 1;
        }
    }
    return q;
}


int* removeFirstLast(int* arr, int size, int& newSize) {
    if (size <= 2) {
        newSize = 0;
        return nullptr;
    }

    newSize = size - 2;
    int* newArr = new int[newSize];
    for (int i = 0; i < newSize; i++) {
        newArr[i] = arr[i + 1];
    }
    return newArr;
}


void generateRandomArray(int* arr, int size, int minVal, int maxVal) {
    srand(time(0));
    for (int i = 0; i < size; i++) {
        arr[i] = minVal + rand() % (maxVal - minVal + 1);
    }
}


int* getSortedArray(int* arr, int size) {
    int* sorted = new int[size];
    for (int i = 0; i < size; i++) {
        sorted[i] = arr[i];
    }

    for (int i = 0; i < size - 1; i++) {
        for (int j = 0; j < size - i - 1; j++) {
            if (sorted[j] > sorted[j + 1]) {
                swap(sorted[j], sorted[j + 1]);
            }
        }
    }
    return sorted;
}

int main() {
    setlocale(LC_ALL, "Russian");

    int size;
    cout << "Введите размер массива: ";
    cin >> size;

    if (size <= 0) {
        cerr << "Ошибка: размер массива должен быть положительным!\n";
        return 1;
    }

    int* arr = new int[size];

    cout << "Выберите способ заполнения массива (1 - вручную, 2 - случайно): ";
    int choice;
    cin >> choice;

    if (choice == 1) {
        inputArray(arr, size);
    }
    else if (choice == 2) {
        int minVal, maxVal;
        cout << "Введите минимальное и максимальное значение: ";
        cin >> minVal >> maxVal;
        generateRandomArray(arr, size, minVal, maxVal);
    }
    else {
        cerr << "Ошибка: неверный выбор!\n";
        delete[] arr;
        return 1;
    }

    printArray(arr, size);
    double d = checkArithmetic(arr, size);
    if (d != 0) {
        cout << "Массив образует арифметическую прогрессию с разностью " << d << endl;
    }
    else {
        cout << "Массив не образует арифметическую прогрессию\n";
    }

    double q = checkGeometric(arr, size);
    if (q != 1) {
        cout << "Массив образует геометрическую прогрессию со знаменателем " << q << endl;
    }
    else {
        cout << "Массив не образует геометрическую прогрессию\n";
    }

    int newSize;
    int* trimmedArr = removeFirstLast(arr, size, newSize);
    if (newSize > 0) {
        cout << "Массив после удаления первого и последнего элементов:\n";
        printArray(trimmedArr, newSize);
        delete[] trimmedArr;
    }

    int* sortedArr = getSortedArray(arr, size);
    cout << "Отсортированный массив:\n";
    printArray(sortedArr, size);

    delete[] arr;
    delete[] sortedArr;

    return 0;
}