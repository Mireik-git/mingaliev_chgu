﻿#include <iostream>
#include <vector>
#include <iomanip>
#include <clocale>

using namespace std;

int sumOfArray(const vector<int>& arr) {
    int sum = 0;
    for (int num : arr) {
        sum += num;
    }
    return sum;
}

void printMatrix(const vector<vector<int>>& matrix) {
    for (const auto& row : matrix) {
        for (int num : row) {
            cout << setw(4) << num;
        }
        cout << endl;
    }
}

int main() {
    setlocale(LC_ALL, "Russian");

    int n, m;
    cout << "Введите количество строк (n): ";
    cin >> n;
    cout << "Введите количество столбцов (m): ";
    cin >> m;

    vector<vector<int>> matrix(n, vector<int>(m));

    cout << "Введите элементы матрицы:" << endl;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            cin >> matrix[i][j];
        }
    }

    cout << "\nИсходная матрица:" << endl;
    printMatrix(matrix);

    vector<int> columnSums(m, 0);
    for (int j = 0; j < m; j++) {
        vector<int> column;
        for (int i = 0; i < n; i++) {
            column.push_back(matrix[i][j]);
        }
        columnSums[j] = sumOfArray(column);
    }

    matrix.push_back(columnSums);

    cout << "\nМатрица с суммами столбцов:" << endl;
    printMatrix(matrix);

    return 0;
}